package view;

import javax.swing.*;
import java.awt.*;

public class MainView extends JFrame {
    public JRadioButton rbMovies = new JRadioButton("Movies");
    public JRadioButton rbGenres = new JRadioButton("Genre");
    public JTextField txtQuery = new JTextField();
    public JButton btnSubmit = new JButton("Submit");
    public JTable table = new JTable();
    public JTextField txtFilter = new JTextField(15);
    public JButton btnNewGenre = new JButton("New Genre");
    public JButton btnNewMovie = new JButton("New Movie");

    public MainView() {
        setTitle("Netflix Database Manager");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        ButtonGroup bg = new ButtonGroup();
        bg.add(rbMovies);
        bg.add(rbGenres);

        JPanel topPanel = new JPanel(new GridLayout(3, 1));
        JPanel radioPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        radioPanel.add(rbMovies);
        radioPanel.add(rbGenres);
        
        JPanel queryPanel = new JPanel(new BorderLayout());
        queryPanel.add(txtQuery, BorderLayout.CENTER);
        queryPanel.add(btnSubmit, BorderLayout.EAST);
        
        topPanel.add(radioPanel);
        topPanel.add(queryPanel);

        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.add(new JLabel("Filtro:"));
        bottomPanel.add(txtFilter);
        bottomPanel.add(btnNewGenre);
        bottomPanel.add(btnNewMovie);
        add(bottomPanel, BorderLayout.SOUTH);
    }
}