package view;

import javax.swing.*;
import java.awt.*;

public class NewGenreView extends JDialog {
    public JTextField txtName = new JTextField(15);
    public JButton btnSave = new JButton("Save");
    public JButton btnCancel = new JButton("Cancel");

    public NewGenreView(JFrame parent) {
        super(parent, "New Genre", true);
        setSize(300, 150);
        setLocationRelativeTo(parent);
        setLayout(new FlowLayout(FlowLayout.CENTER, 10, 20));

        add(new JLabel("Name:"));
        add(txtName);
        add(btnSave);
        add(btnCancel);
    }
}