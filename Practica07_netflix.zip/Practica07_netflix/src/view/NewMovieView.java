package view;

import javax.swing.*;
import java.awt.*;
import model.GenreItem;

public class NewMovieView extends JDialog {
    public JComboBox<GenreItem> cbGenre = new JComboBox<>();
    public JTextField txtTitle = new JTextField(15);
    public JTextArea txtSummary = new JTextArea(4, 15);
    public JSpinner spYear = new JSpinner(new SpinnerNumberModel(2023, 1900, 2100, 1));
    public JSpinner spDuration = new JSpinner(new SpinnerNumberModel(120, 1, 500, 1));
    public JButton btnSave = new JButton("Save");
    public JButton btnCancel = new JButton("Cancel");

    public NewMovieView(JFrame parent) {
        super(parent, "New Movie", true);
        setSize(350, 350);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(6, 2, 5, 5));

        JSpinner.NumberEditor editor = new JSpinner.NumberEditor(spYear, "#");
        spYear.setEditor(editor);

        add(new JLabel("Genre:")); add(cbGenre);
        add(new JLabel("Title:")); add(txtTitle);
        add(new JLabel("Summary:")); add(new JScrollPane(txtSummary));
        add(new JLabel("Year:")); add(spYear);
        add(new JLabel("Duration:")); add(spDuration);
        
        JPanel btnPanel = new JPanel();
        btnPanel.add(btnSave);
        btnPanel.add(btnCancel);
        add(new JLabel("")); 
        add(btnPanel);
    }
}