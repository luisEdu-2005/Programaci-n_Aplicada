package controller;

import model.*;
import view.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

public class AppController {
    private MainView mainView;
    private NetflixModel model;
    private TableRowSorter<DefaultTableModel> rowSorter;

    public AppController(MainView mainView, NetflixModel model) {
        this.mainView = mainView;
        this.model = model;
        initController();
    }

    private void initController() {
        mainView.rbMovies.addActionListener(e -> mainView.txtQuery.setText("SELECT * FROM movie"));
        mainView.rbGenres.addActionListener(e -> mainView.txtQuery.setText("SELECT * FROM genre"));

        mainView.btnSubmit.addActionListener(e -> executeQuery());

        mainView.txtFilter.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filterTable(); }
            public void removeUpdate(DocumentEvent e) { filterTable(); }
            public void changedUpdate(DocumentEvent e) { filterTable(); }
        });

        mainView.btnNewGenre.addActionListener(e -> openNewGenreWindow());

        mainView.btnNewMovie.addActionListener(e -> openNewMovieWindow());
    }

    private void executeQuery() {
        String query = mainView.txtQuery.getText();
        if (query.isEmpty()) return;
        try {
            DefaultTableModel tableModel = model.executeQuery(query);
            mainView.table.setModel(tableModel);
            rowSorter = new TableRowSorter<>(tableModel);
            mainView.table.setRowSorter(rowSorter);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(mainView, "Error SQL: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void filterTable() {
        String text = mainView.txtFilter.getText();
        if (rowSorter == null) return;
        if (text.trim().length() == 0) {
            rowSorter.setRowFilter(null);
        } else {
            rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
        }
    }

    private void openNewGenreWindow() {
        NewGenreView genreView = new NewGenreView(mainView);
        
        genreView.btnCancel.addActionListener(e -> genreView.dispose());
        
        genreView.btnSave.addActionListener(e -> {
            String name = genreView.txtName.getText();
            if (!name.isEmpty()) {
                try {
                    model.insertGenre(name);
                    JOptionPane.showMessageDialog(genreView, "Genre guardado con éxito.");
                    genreView.dispose();
                    if (mainView.rbGenres.isSelected()) executeQuery(); 
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(genreView, "Error al guardar: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        genreView.setVisible(true);
    }

    private void openNewMovieWindow() {
        NewMovieView movieView = new NewMovieView(mainView);
 
        try {
            List<GenreItem> genres = model.getGenres();
            for (GenreItem g : genres) {
                movieView.cbGenre.addItem(g);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(movieView, "Error al cargar géneros.");
            return;
        }

        movieView.btnCancel.addActionListener(e -> movieView.dispose());

        movieView.btnSave.addActionListener(e -> {
            try {
                GenreItem selectedGenre = (GenreItem) movieView.cbGenre.getSelectedItem();
                String title = movieView.txtTitle.getText();
                String summary = movieView.txtSummary.getText();
                int year = (Integer) movieView.spYear.getValue();
                int duration = (Integer) movieView.spDuration.getValue();

                if (selectedGenre != null && !title.isEmpty()) {
                    model.insertMovie(selectedGenre.getId(), title, summary, year, duration);
                    JOptionPane.showMessageDialog(movieView, "Película guardada con éxito.");
                    movieView.dispose();
                    if (mainView.rbMovies.isSelected()) executeQuery(); 
                } else {
                    JOptionPane.showMessageDialog(movieView, "Llene los campos obligatorios.");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(movieView, "Error al guardar: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        movieView.setVisible(true);
    }
}