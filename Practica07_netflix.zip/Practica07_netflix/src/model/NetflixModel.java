package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import java.util.Vector;

public class NetflixModel {
    private final String URL = "jdbc:mysql://localhost:3306/netflix";
    private final String USER = "root"; 
    private final String PASS = "1234"; 

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public DefaultTableModel executeQuery(String query) throws SQLException {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();

            Vector<String> columnNames = new Vector<>();
            for (int column = 1; column <= columnCount; column++) {
                columnNames.add(metaData.getColumnName(column));
            }

            Vector<Vector<Object>> data = new Vector<>();
            while (rs.next()) {
                Vector<Object> vector = new Vector<>();
                for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                    vector.add(rs.getObject(columnIndex));
                }
                data.add(vector);
            }
            return new DefaultTableModel(data, columnNames);
        }
    }

    private int getNextId(String table, String idColumn) throws SQLException {
        String query = "SELECT MAX(" + idColumn + ") FROM " + table;
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            if (rs.next()) {
                return rs.getInt(1) + 1;
            }
            return 1;
        }
    }

    public void insertGenre(String name) throws SQLException {
        int nextId = getNextId("genre", "id_genre");
        String sql = "INSERT INTO genre (id_genre, name) VALUES (?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, nextId);
            pstmt.setString(2, name);
            pstmt.executeUpdate();
        }
    }

    public void insertMovie(int genreId, String title, String summary, int year, int duration) throws SQLException {
        int nextId = getNextId("movie", "id_movie");
        String sql = "INSERT INTO movie (id_movie, id_genre, title, summary, year, duration) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, nextId);
            pstmt.setInt(2, genreId);
            pstmt.setString(3, title);
            pstmt.setString(4, summary);
            pstmt.setInt(5, year);
            pstmt.setInt(6, duration);
            pstmt.executeUpdate();
        }
    }

    public List<GenreItem> getGenres() throws SQLException {
        List<GenreItem> genres = new ArrayList<>();
        String sql = "SELECT id_genre, name FROM genre";
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                genres.add(new GenreItem(rs.getInt("id_genre"), rs.getString("name")));
            }
        }
        return genres;
    }
}