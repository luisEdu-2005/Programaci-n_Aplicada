import java.util.Objects;

public class Estudiante {
    private String id;
    private String nombre;
    private String carrera;
    private int nivel;

    public Estudiante(String id, String nombre, String carrera, int nivel) {
        this.id = id;
        this.nombre = nombre;
        this.carrera = carrera;
        this.nivel = nivel;
    }

    public String getId() { return id; } 
    public String getNombre() { return nombre; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Estudiante est = (Estudiante) o;
        return Objects.equals(id, est.id);
    }
}