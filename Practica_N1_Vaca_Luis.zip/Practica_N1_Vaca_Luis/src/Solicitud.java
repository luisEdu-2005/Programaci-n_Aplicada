public class Solicitud {
    private Estudiante responsable;
    private int cantidadPersonas;
    private String bloqueHorario;

    public Solicitud(Estudiante responsable, int cantidadPersonas, String bloqueHorario) {
        this.responsable = responsable;
        this.cantidadPersonas = cantidadPersonas;
        this.bloqueHorario = bloqueHorario;
    }

    public int getCantidadPersonas() { return cantidadPersonas; }
    public String getBloqueHorario() { return bloqueHorario; }
    public Estudiante getResponsable() { return responsable; }
}