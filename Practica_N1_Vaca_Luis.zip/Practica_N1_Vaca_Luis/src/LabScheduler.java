public class LabScheduler {
    private GestorGenerico<Estudiante> estudiantes = new GestorGenerico<>();
    private GestorGenerico<Laboratorio> laboratorios = new GestorGenerico<>();

    public void procesarReserva(String idEst, int indiceLab, String horario, int cant) {
        // Buscar estudiante
        Estudiante encontrado = null;
        for (int i = 0; i < estudiantes.getElementos().size(); i++) {
            if (estudiantes.getElementos().get(i).getId().equals(idEst)) {
                encontrado = estudiantes.getElementos().get(i);
            }
        }

        if (encontrado == null) {
            System.out.println("Error: Estudiante no registrado.");
            return;
        }

        Laboratorio lab = laboratorios.getElementos().get(indiceLab);

        // Verificar si hay espacio en el horario seleccionado (Máximo 30 total)
        if (lab.verificarEspacio(horario, cant)) {
            lab.registrarUso(horario, cant);
            System.out.println("Reserva exitosa en " + lab.getNombre() + " turno " + horario);
        } else {
            // Mandar a la Queue si está lleno
            Solicitud soli = new Solicitud(encontrado, cant, horario);
            lab.getListaEspera().add(soli);
            System.out.println("Capacidad superada. " + encontrado.getNombre() + " esta en lista de espera.");
        }
    }

    public void liberarLaboratorio(int indiceLab, String horario, int cant) {
        Laboratorio lab = laboratorios.getElementos().get(indiceLab);
        lab.liberarUso(horario, cant);
        System.out.println("Espacio liberado.");

        // Lógica de Queue automática
        if (!lab.getListaEspera().isEmpty()) {
            Solicitud espera = lab.getListaEspera().peek();
            // Si el que sigue en la cola cabe ahora, lo dejamos entrar
            if (lab.verificarEspacio(espera.getBloqueHorario(), espera.getCantidadPersonas())) {
                lab.getListaEspera().poll();
                lab.registrarUso(espera.getBloqueHorario(), espera.getCantidadPersonas());
                System.out.println("AVISO: El grupo de " + espera.getResponsable().getNombre() + " ha salido de la cola e ingresado.");
            }
        }
    }

    public void mostrarReporte() {
        System.out.println("\n--- REPORTE DE LABORATORIOS ---");
        for (int i = 0; i < laboratorios.getElementos().size(); i++) {
            Laboratorio l = laboratorios.getElementos().get(i);
            System.out.println("Laboratorio: " + l.getNombre());
            System.out.println("Solicitudes esperando en cola: " + l.getListaEspera().size());
            System.out.println("-----------------------------");
        }
    }

    public GestorGenerico<Estudiante> getEstudiantes() { return estudiantes; }
    public GestorGenerico<Laboratorio> getLaboratorios() { return laboratorios; }
}