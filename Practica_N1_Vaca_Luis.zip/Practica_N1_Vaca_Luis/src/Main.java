import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        LabScheduler sistema = new LabScheduler();

        
        sistema.getLaboratorios().agregar(new Laboratorio("L1", "Interaccion humano maquina"));
        sistema.getLaboratorios().agregar(new Laboratorio("L2", "Networking 1"));
        sistema.getLaboratorios().agregar(new Laboratorio("L3", "Networking 2"));
        sistema.getLaboratorios().agregar(new Laboratorio("L4", "Desarrollo de Software"));
        sistema.getLaboratorios().agregar(new Laboratorio("L5", "Arquitectura de Computadores"));

        System.out.println("--- ACCESO AL SISTEMA ---");
        System.out.print("Usuario: "); String user = lector.nextLine();
        System.out.print("Contraseña: "); String pass = lector.nextLine();

        if (user.equals("Admin") && pass.equals("1234")) {
            int opcion = 0;
            while (opcion != 5) {
                System.out.println("\n*** MENU PRINCIPAL ***");
                System.out.println("1. Registrar Estudiante");
                System.out.println("2. Solicitar Laboratorio (Reserva)");
                System.out.println("3. Liberar Espacio (Salida)");
                System.out.println("4. Reporte de Ocupacion");
                System.out.println("5. Salir");
                System.out.print("Seleccione: ");
                opcion = lector.nextInt(); lector.nextLine();

                if (opcion == 1) {
                    System.out.print("ID: "); String id = lector.nextLine();
                    System.out.print("Nombre: "); String n = lector.nextLine();
                    System.out.print("Carrera: "); String c = lector.nextLine();
                    System.out.print("Nivel: "); int nv = lector.nextInt();
                    if (sistema.getEstudiantes().agregar(new Estudiante(id, n, c, nv))) {
                        System.out.println("Estudiante registrado.");
                    } else {
                        System.out.println("Error: El ID ya existe.");
                    }

                } else if (opcion == 2) {
                    System.out.println("Elija Laboratorio (0-4):");
                    for(int i=0; i<5; i++) System.out.println(i + ". " + sistema.getLaboratorios().getElementos().get(i).getNombre());
                    int labIdx = lector.nextInt();

                    System.out.println("Seleccione el Turno:");
                    System.out.println("1. 07:00 - 09:00");
                    System.out.println("2. 09:00 - 11:00");
                    System.out.println("3. 11:00 - 13:00");
                    int turno = lector.nextInt(); lector.nextLine();
                    
                    String horario = (turno == 1) ? "07:00-09:00" : (turno == 2) ? "09:00-11:00" : "11:00-13:00";

                    System.out.print("ID Responsable: "); String idEst = lector.nextLine();
                    System.out.print("¿Cuantos estudiantes ingresan? (Max 30): "); int cant = lector.nextInt();

                    if (cant > 30 || cant <= 0) {
                        System.out.println("Error: Capacidad permitida por grupo es de 1 a 30.");
                    } else {
                        sistema.procesarReserva(idEst, labIdx, horario, cant);
                    }

                } else if (opcion == 3) {
                    System.out.print("Indice de Lab (0-4): "); int lIdx = lector.nextInt();
                    System.out.println("Turno a liberar (1, 2 o 3): "); int t = lector.nextInt();
                    String h = (t == 1) ? "07:00-09:00" : (t == 2) ? "09:00-11:00" : "11:00-13:00";
                    System.out.print("Cantidad de personas que salen: "); int c = lector.nextInt();
                    
                    sistema.liberarLaboratorio(lIdx, h, c);

                } else if (opcion == 4) {
                    sistema.mostrarReporte();
                }
            }
        } else {
            System.out.println("Credenciales incorrectas.");
        }
    }
}