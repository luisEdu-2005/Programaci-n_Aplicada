public class Horario {
    private String turno; 

    public Horario(String turno) {
        this.turno = turno; 
    }

    public String getTurno() { 
        return turno; 
    }

    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Horario horario = (Horario) o;
        return turno.equals(horario.turno);
    }

    @Override
    public int hashCode() {
        return turno.hashCode();
    }
}