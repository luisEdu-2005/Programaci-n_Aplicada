import java.util.LinkedList;
import java.util.Queue;
import java.util.HashMap;
import java.util.Map;

public class Laboratorio {
    private String id;
    private String nombre;
    private int capacidadMax = 30;
    private Map<String, Integer> ocupacionPorHorario; 
    private Queue<Solicitud> listaEspera;

    public Laboratorio(String id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.ocupacionPorHorario = new HashMap<>();
        this.listaEspera = new LinkedList<>();
    }

    
    public boolean verificarEspacio(String horario, int cantidad) {
        int actual = ocupacionPorHorario.getOrDefault(horario, 0);
        return (actual + cantidad) <= capacidadMax;
    }

    
    public void registrarUso(String horario, int cantidad) {
        int actual = ocupacionPorHorario.getOrDefault(horario, 0);
        ocupacionPorHorario.put(horario, actual + cantidad);
    }

    
    public void liberarUso(String horario, int cantidad) {
        int actual = ocupacionPorHorario.getOrDefault(horario, 0);
        int nuevo = actual - cantidad;
        if (nuevo < 0) nuevo = 0;
        ocupacionPorHorario.put(horario, nuevo);
    }

    public String getNombre() { return nombre; }
    public Queue<Solicitud> getListaEspera() { return listaEspera; }
}