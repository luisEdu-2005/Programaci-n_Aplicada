import java.util.ArrayList;
import java.util.List;

public class GestorGenerico<T> {
    private List<T> lista;

    public GestorGenerico() {
        this.lista = new ArrayList<>();
    }

    public boolean agregar(T objeto) {
        if (!lista.contains(objeto)) {
            lista.add(objeto);
            return true;
        }
        return false;
    }

    public List<T> getElementos() { // <--- Este nombre es el que buscaba LabScheduler
        return lista;
    }
}