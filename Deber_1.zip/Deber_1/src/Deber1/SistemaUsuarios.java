package Deber1;

import java.util.Scanner;

public class SistemaUsuarios {

    
    static class Usuario {

        String nombre;
        String correo;

        Usuario(String nombre, String correo) {
            this.nombre = nombre;
            this.correo = correo;
        }

        @Override
        public String toString() {
            return "Nombre: " + nombre + " | Correo: " + correo;
        }
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Usuario[] usuarios = new Usuario[50];
        int contador = 0;

        
        System.out.println("===== LOGIN =====");

        System.out.print("Usuario: ");
        String user = sc.nextLine();

        System.out.print("Contraseña: ");
        String pass = sc.nextLine();

        if (user.equals("admin") && pass.equals("1234")) {

            System.out.println("\nAcceso permitido.");

            int opcion = 0;

            
            while (opcion != 5) {

                System.out.println("\n===== MENÚ PRINCIPAL =====");
                System.out.println("1. Agregar usuario");
                System.out.println("2. Mostrar usuarios");
                System.out.println("3. Buscar usuario");
                System.out.println("4. Editar usuario");
                System.out.println("5. Salir");

                System.out.print("Seleccione una opción: ");
                opcion = Integer.parseInt(sc.nextLine());

                switch (opcion) {

                    
                    case 1:

                        System.out.print("Ingrese nombre: ");
                        String nombre = sc.nextLine();

                        System.out.print("Ingrese correo: ");
                        String correo = sc.nextLine();

                        usuarios[contador++] = new Usuario(nombre, correo);

                        System.out.println("Usuario agregado correctamente.");
                        break;

                    
                    case 2:

                        System.out.println("\n===== LISTA DE USUARIOS =====");

                        if (contador == 0) {

                            System.out.println("No existen usuarios registrados.");

                        } else {

                            for (int i = 0; i < contador; i++) {
                                System.out.println((i + 1) + ". " + usuarios[i]);
                            }
                        }

                        break;

                    
                    case 3:

                        System.out.print("Ingrese el nombre a buscar: ");
                        String buscar = sc.nextLine();

                        boolean encontrado = false;

                        for (int i = 0; i < contador; i++) {

                            if (usuarios[i].nombre.equalsIgnoreCase(buscar)) {

                                System.out.println("Usuario encontrado:");
                                System.out.println(usuarios[i]);

                                encontrado = true;
                            }
                        }

                        if (!encontrado) {
                            System.out.println("Usuario no encontrado.");
                        }

                        break;

                    
                    case 4:

                        System.out.print("Ingrese el nombre del usuario a editar: ");
                        String editar = sc.nextLine();

                        boolean editado = false;

                        for (int i = 0; i < contador; i++) {

                            if (usuarios[i].nombre.equalsIgnoreCase(editar)) {

                                System.out.print("Nuevo nombre: ");
                                usuarios[i].nombre = sc.nextLine();

                                System.out.print("Nuevo correo: ");
                                usuarios[i].correo = sc.nextLine();

                                System.out.println("Usuario actualizado.");

                                editado = true;
                                break;
                            }
                        }

                        if (!editado) {
                            System.out.println("Usuario no encontrado.");
                        }

                        break;

                   
                    case 5:

                        System.out.println("Saliendo del sistema...");
                        break;

                    default:

                        System.out.println("Opción inválida.");
                }
            }

        } else {

            System.out.println("Credenciales incorrectas.");
        }

        sc.close();
    }
}