package Gestion_Canchas;

public class Cancha {
    private String codigo;
    private String tipo;
    private String ubicacion;
    private Double costoHora; 
    private boolean reservada;
    private Cliente clienteActual; 
    private Integer horasReserva; 
    private int contadorReservas = 0;

    public Cancha(String codigo, String tipo, String ubicacion, Double costoHora) {
        this.codigo = codigo;
        this.tipo = tipo;
        this.ubicacion = ubicacion;
        this.costoHora = costoHora;
        this.reservada = false;
    }

    public void registrarReserva(Cliente cliente, Integer horas) {
        this.clienteActual = cliente;
        this.horasReserva = horas;
        this.reservada = true;
        this.contadorReservas++;
    }

    public void liberar() {
        this.clienteActual = null;
        this.horasReserva = null;
        this.reservada = false;
    }

    // Getters
    public String getCodigo() { return codigo; }
    public String getTipo() { return tipo; }
    public String getUbicacion() { return ubicacion; }
    public boolean isReservada() { return reservada; }
    public Double getCostoHora() { return costoHora; }
    public Cliente getClienteActual() { return clienteActual; }
    public int getContadorReservas() { return contadorReservas; }

    @Override
    public String toString() {
        String estado = reservada ? "[OCUPADA - " + clienteActual.getNombre() + "]" : "[LIBRE]";
        return String.format("Cód: %-5s | %-12s | %-12s | $%s/h | %s", 
                codigo, tipo, ubicacion, costoHora, estado);
    }
}