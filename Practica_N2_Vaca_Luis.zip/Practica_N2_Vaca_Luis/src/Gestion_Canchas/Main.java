package Gestion_Canchas;

import java.util.Scanner;

public class Main {
    private static GestionCancha<Cancha> gestor = new GestionCancha<>();
    private static Scanner sc = new Scanner(System.in);
    private static final Usuario ADMIN = new Usuario("SportCenter", "1234");

    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("   SPORTCENTER SOLUTIONS - BIENVENIDO");
        System.out.println("========================================");
        
        if (login()) {
            ejecutarMenu();
        } else {
            System.out.println("\n [!] Acceso denegado.");
        }
    }

    private static boolean login() {
        System.out.println("\n >>> INICIO DE SESIÓN <<<");
        System.out.print("  Usuario: "); String u = sc.nextLine();
        System.out.print("  Password: "); String p = sc.nextLine();
        return ADMIN.autenticar(u, p);
    }

    private static void ejecutarMenu() {
        int op = -1;
        while (op != 0) {
            System.out.println("\n========================================");
            System.out.println("          PANEL DE CONTROL");
            System.out.println("========================================");
            System.out.println("  1. Registrar Cancha");
            System.out.println("  2. Ver Disponibilidad");
            System.out.println("  3. Realizar Reserva");
            System.out.println("  4. Liberar Cancha");
            System.out.println("  5. Estadísticas");
            System.out.println("  0. Salir");
            System.out.println("----------------------------------------");
            System.out.print("  Seleccione: ");
            
            try {
                op = Integer.parseInt(sc.nextLine());
                switch (op) {
                    case 1 -> menuRegistrar();
                    case 2 -> menuConsultar();
                    case 3 -> menuReservar();
                    case 4 -> menuLiberar();
                    case 5 -> menuEstadisticas();
                }
            } catch (Exception e) {
                System.out.println("\n [!] Error: Ingrese un número válido.");
            }
        }
    }

    private static void menuRegistrar() {
        System.out.println("\n--- REGISTRO ---");
        System.out.print("  Código: "); String c = sc.nextLine();
        System.out.print("  Tipo: "); String t = sc.nextLine();
        System.out.print("  Ubicación: "); String u = sc.nextLine();
        System.out.print("  Costo/Hora ($): "); double p = Double.parseDouble(sc.nextLine());
        
        if (gestor.agregarCancha(new Cancha(c, t, u, p))) {
            System.out.println(" [+] Éxito.");
        } else {
            System.out.println(" [!] Límite alcanzado.");
        }
    }

    private static void menuConsultar() {
        System.out.println("\n--- LISTADO ---");
        if (gestor.listarCanchas().isEmpty()) {
            System.out.println("  Vacio.");
        } else {
            System.out.printf("  %-8s | %-12s | %-12s | %-8s | %-10s\n", "ID", "TIPO", "UBICACIÓN", "COSTO", "ESTADO");
            gestor.listarCanchas().forEach(c -> {
                String est = c.isReservada() ? "OCUPADA" : "LIBRE";
                System.out.printf("  %-8s | %-12s | %-12s | $%-7.2f | %-10s\n", 
                                  c.getCodigo(), c.getTipo(), c.getUbicacion(), c.getCostoHora(), est);
            });
        }
    }

    private static void menuReservar() {
        System.out.println("\n--- RESERVA ---");
        System.out.print("  Código: "); String cod = sc.nextLine();
        System.out.print("  Cliente: "); String nom = sc.nextLine();
        System.out.print("  Cédula: "); String ced = sc.nextLine();
        System.out.print("  Horas: "); int h = Integer.parseInt(sc.nextLine());

        double total = gestor.procesarReserva(cod, nom, ced, h);
        if (total != -1) {
            Cancha c = gestor.buscarPorCodigo(cod);
            System.out.println("\n****************************************");
            System.out.println("           TICKET DE PAGO               ");
            System.out.println("****************************************");
            System.out.println("  CLIENTE:   " + c.getClienteActual().toString());
            System.out.println("  CANCHA:    " + c.getTipo() + " [" + cod + "]");
            System.out.println("  UBICACIÓN: " + c.getUbicacion());
            System.out.printf("  TOTAL:     $%.2f USD\n", total);
            System.out.println("****************************************");
            notificar("RESERVA EXITOSA", cod);
        } else {
            System.out.println("\n [X] Fallo: Ocupada o Inválida.");
        }
    }

    private static void menuLiberar() {
        System.out.print("\n  Código a liberar: ");
        String cod = sc.nextLine();
        if (gestor.procesarLiberacion(cod)) {
            System.out.println(" [+] Liberada.");
        } else {
            System.out.println(" [!] Error.");
        }
    }

    private static void menuEstadisticas() {
        System.out.println("\n--- REPORTE ---");
        Cancha popular = gestor.obtenerMasSolicitada();
        System.out.println("  > Registradas: " + gestor.listarCanchas().size());
        System.out.println("  > Ocupadas:    " + gestor.contarOcupadas());
        if (popular != null && popular.getContadorReservas() > 0) {
            System.out.println("  > Más popular: " + popular.getTipo() + " (" + popular.getContadorReservas() + " veces)");
        }
    }

    public static void notificar(String mensaje, String... cods) {
        for (String c : cods) System.out.println(" [SISTEMA]: " + mensaje + " -> " + c);
    }
}