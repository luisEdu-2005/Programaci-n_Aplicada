package Gestion_Canchas;

import java.util.ArrayList;
import java.util.List;

public class GestionCancha<T extends Cancha> {
    private List<T> lista = new ArrayList<>();
    private final int MAX = 50;

    public boolean agregarCancha(T cancha) {
        if (lista.size() < MAX) {
            lista.add(cancha);
            return true;
        }
        return false;
    }

    public List<T> listarCanchas() {
        return lista;
    }

    public T buscarPorCodigo(String codigo) {
        for (T c : lista) {
            if (c.getCodigo().equalsIgnoreCase(codigo)) return c;
        }
        return null;
    }

    public double procesarReserva(String codigo, String nombre, String cedula, int horas) {
        T cancha = buscarPorCodigo(codigo);
        if (cancha != null && !cancha.isReservada()) {
            Cliente nuevoCliente = new Cliente(nombre, cedula);
            cancha.registrarReserva(nuevoCliente, horas);
            return cancha.getCostoHora() * horas;
        }
        return -1;
    }

    public boolean procesarLiberacion(String codigo) {
        T cancha = buscarPorCodigo(codigo);
        if (cancha != null && cancha.isReservada()) {
            cancha.liberar();
            return true;
        }
        return false;
    }

    public T obtenerMasSolicitada() {
        if (lista.isEmpty()) return null;
        T popular = lista.get(0);
        for (T c : lista) {
            if (c.getContadorReservas() > popular.getContadorReservas()) {
                popular = c;
            }
        }
        return popular;
    }

    public long contarOcupadas() {
        return lista.stream().filter(Cancha::isReservada).count();
    }
}