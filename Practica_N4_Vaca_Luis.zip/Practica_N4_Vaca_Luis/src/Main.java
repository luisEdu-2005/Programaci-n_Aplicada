import controller.RegexController;
import view.RegexView;

public class Main {

    public static void main(String[] args){

        RegexView view=new RegexView();

        new RegexController(view);

        view.setVisible(true);
    }
}