package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

import model.Text;
import model.TextDAO;
import view.RegexView;

public class RegexController implements ActionListener{

    private RegexView view;
    private TextDAO dao;

    public RegexController(RegexView view){
        this.view=view;

        view.btnGuardar.addActionListener(this);
        view.btnBuscar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e){

        if(e.getSource()==view.btnGuardar)
            guardarTexto();

        if(e.getSource()==view.btnBuscar)
            analizarArchivo();
    }

    public void guardarTexto(){

        Text text=new Text(view.txtTexto.getText());

        dao=new TextDAO(text);

        if(dao.saveText())
            JOptionPane.showMessageDialog(null,"Archivo guardado");
        else
            JOptionPane.showMessageDialog(null,"Error al guardar");
    }

    public void analizarArchivo(){

        try{

            view.modeloLista.clear();

            dao=new TextDAO(new Text());

            Text contenido=dao.readText();

            String texto=contenido.getContenido();
            String er=view.txtRegex.getText();

            Pattern patron=Pattern.compile(er);
            Matcher buscar=patron.matcher(texto);

            int contador=0;

            while(buscar.find()){
                contador++;
                view.modeloLista.addElement(buscar.group());
            }

            view.txtCantidad.setText(contador+"");

        }catch(Exception e){

            JOptionPane.showMessageDialog(null,"Expresión inválida");
        }
    }
}