package view;

import javax.swing.*;
import javax.swing.border.TitledBorder;

public class RegexView extends JFrame{

    public JTextArea txtTexto;
    public JTextField txtRegex,txtCantidad;
    public JButton btnGuardar,btnBuscar;
    public JList<String> lista;
    public DefaultListModel<String> modeloLista;

    public RegexView(){

        setTitle("Analizador Regex");
        setSize(760,650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        JPanel pTexto=new JPanel();
        pTexto.setLayout(null);
        pTexto.setBorder(new TitledBorder("Archivo de texto"));
        pTexto.setBounds(15,20,710,330);

        txtTexto=new JTextArea();

        JScrollPane s1=new JScrollPane(txtTexto);
        s1.setBounds(15,25,670,230);

        btnGuardar=new JButton("GUARDAR");
        btnGuardar.setBounds(575,270,110,25);

        pTexto.add(s1);
        pTexto.add(btnGuardar);

        getContentPane().add(pTexto);


        JPanel pAnalizar=new JPanel();
        pAnalizar.setLayout(null);
        pAnalizar.setBorder(new TitledBorder("Analizar datos"));
        pAnalizar.setBounds(15,380,710,210);


        JLabel l1=new JLabel("EXPRESIÓN REGULAR");
        l1.setBounds(15,35,160,25);

        txtRegex=new JTextField();
        txtRegex.setBounds(190,35,390,25);

        btnBuscar=new JButton("...");
        btnBuscar.setBounds(590,35,50,25);


        JLabel l2=new JLabel("Número de palabras encontradas");
        l2.setBounds(15,85,230,25);

        txtCantidad=new JTextField();
        txtCantidad.setEditable(false);
        txtCantidad.setBounds(285,85,130,25);


        JLabel l3=new JLabel("Listado de palabras:");
        l3.setBounds(15,135,150,25);


        modeloLista=new DefaultListModel<>();

        JScrollPane s2=new JScrollPane();
        s2.setBounds(201,121,360,75);


        pAnalizar.add(l1);
        pAnalizar.add(txtRegex);
        pAnalizar.add(btnBuscar);
        pAnalizar.add(l2);
        pAnalizar.add(txtCantidad);
        pAnalizar.add(l3);
        pAnalizar.add(s2);
        
                lista=new JList<>(modeloLista);
                s2.setViewportView(lista);

        getContentPane().add(pAnalizar);
    }
}