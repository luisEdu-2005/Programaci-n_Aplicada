package model;

import java.io.*;

public class TextDAO {

    private final String ruta="src/practica06/archivo.txt";
    private Text text;

    public TextDAO(Text text){
        this.text=text;
    }
    public boolean saveText(){

        try{

            FileWriter escribir=new FileWriter(ruta);

            escribir.write(text.getContenido());

            escribir.close();

            return true;

        }catch(Exception e){

            e.printStackTrace();
            return false;
        }
    }

    public Text readText(){

        StringBuilder contenido=new StringBuilder();

        try{

            BufferedReader lectura=
                new BufferedReader(
                new FileReader(ruta));

            String linea;

            while((linea=lectura.readLine())!=null){
                contenido.append(linea)
                          .append("\n");
            }

            lectura.close();

        }catch(Exception e){
            e.printStackTrace();
        }

        return new Text(contenido.toString());
    }
}