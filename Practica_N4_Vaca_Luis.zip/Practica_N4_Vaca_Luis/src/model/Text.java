package model;

public class Text {

    private String contenido;

    public Text() {
    }

    public Text(String contenido) {
        this.contenido = contenido;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

}