package practicaN3;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class main {

	public static void main(String[] args) {

		System.out.println("EJERCICIO 1");
		/**
		 * ER=^[A-Za-z0-9ÁÉÍÓÚáéíóú]+$
		 */
		Pattern patron1 = Pattern.compile("^[A-Za-z0-9ÁÉÍÓÚáéíóú]+$");
		String cadenas1 = "Colombia Quito Venezuela2 Braz1l 25Peru";
		String[] palabras1 = cadenas1.split("\\s");
		for (String p : palabras1) {
			Matcher analisis = patron1.matcher(p);
			if (analisis.find()) {
				System.out.println(analisis.group());
			}
		}

		System.out.println("\nEJERCICIO 2");
		/**
		 * ER=^([0-9]{1,3}\\.){3}[0-9]{1,3}$
		 */
		Pattern patron2 = Pattern.compile("^([0-9]{1,3}\\.){3}[0-9]{1,3}$");
		String cadenas2 = "172.165.0.1 214.124.100.0 10.10.10.10 192.168.1.2";
		String[] palabras2 = cadenas2.split("\\s");
		for (String p : palabras2) {
			Matcher analisis = patron2.matcher(p);
			if (analisis.find()) {
				System.out.println(analisis.group());
			}
		}

		System.out.println("\nEJERCICIO 3");
		/**
		 * ER=^(https?|ftp)://[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$
		 */
		Pattern patron3 = Pattern.compile("^(https?|ftp)://[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
		String cadenas3 = "https://www.ups.edu.ec http://google.com ftp://repositorio.net";
		String[] palabras3 = cadenas3.split("\\s");
		for (String p : palabras3) {
			Matcher analisis = patron3.matcher(p);
			if (analisis.find()) {
				System.out.println(analisis.group());
			}
		}

		System.out.println("\nEJERCICIO 4");
		/**
		 * ER=^\\([0-9]{2}\\)-[0-9]{4}-[0-9]{3}$
		 */
		Pattern patron4 = Pattern.compile("^\\([0-9]{2}\\)-[0-9]{4}-[0-9]{3}$");
		String cadenas4 = "(09)-7145-412 (08)-1422-251 (06)-1254-254";
		String[] palabras4 = cadenas4.split("\\s");
		for (String p : palabras4) {
			Matcher analisis = patron4.matcher(p);
			if (analisis.find()) {
				System.out.println(analisis.group());
			}
		}

		System.out.println("\nEJERCICIO 5");
		/**
		 * ER=^[A-F0-9]{4}$
		 */
		Pattern patron5 = Pattern.compile("^[A-F0-9]{4}$");
		String cadenas5 = "01AA B5CF FFFF BBCF";
		String[] palabras5 = cadenas5.split("\\s");
		for (String p : palabras5) {
			Matcher analisis = patron5.matcher(p);
			if (analisis.find()) {
				System.out.println(analisis.group());
			}
		}

		System.out.println("\nEJERCICIO 6");
		/**
		 * ER=^-?[0-9]+(\\.[0-9]{1,3})?$
		 */
		Pattern patron6 = Pattern.compile("^-?[0-9]+(\\.[0-9]{1,3})?$");
		String cadenas6 = "3 -5 2.45 -45.45 45458.254";
		String[] palabras6 = cadenas6.split("\\s");
		for (String p : palabras6) {
			Matcher analisis = patron6.matcher(p);
			if (analisis.find()) {
				System.out.println(analisis.group());
			}
		}

		System.out.println("\nEJERCICIO 7");
		/**
		 * ER=^href=([A-Za-z0-9./]+)$
		 */
		Pattern patron7 = Pattern.compile("^href=([A-Za-z0-9./]+)$");
		String cadenas7 = "href=www.images.com.net href=/img/fto.jpg";
		String[] palabras7 = cadenas7.split("\\s");
		for (String p : palabras7) {
			Matcher analisis = patron7.matcher(p);
			if (analisis.find()) {
				System.out.println(analisis.group());
			}
		}

		System.out.println("\nEJERCICIO 8");
		/**
		 * ER=^[a-zA-ZáéíóúÁÉÍÓÚ]*m[a-zA-ZáéíóúÁÉÍÓÚ]*s$
		 */
		Pattern patron8 = Pattern.compile("^[a-zA-ZáéíóúÁÉÍÓÚ]*m[a-zA-ZáéíóúÁÉÍÓÚ]*s$");
		String cadenas8 = "camas tambores romanticas";
		String[] palabras8 = cadenas8.split("\\s");
		for (String p : palabras8) {
			Matcher analisis = patron8.matcher(p);
			if (analisis.find()) {
				System.out.println(analisis.group());
			}
		}

		System.out.println("\nEJERCICIO 9");
		/**
		 * ER=^[+-][0-9]{3}-[0-9]{3}-[0-9]{4}$
		 */
		Pattern patron9 = Pattern.compile("^[+-][0-9]{3}-[0-9]{3}-[0-9]{4}$");
		String cadenas9 = "+593-987-6543 -541-123-4567 +571-456-7890";
		String[] palabras9 = cadenas9.split("\\s");
		for (String p : palabras9) {
			Matcher analisis = patron9.matcher(p);
			if (analisis.find()) {
				System.out.println(analisis.group());
			}
		}

		System.out.println("\nEJERCICIO 10");
		/**
		 * ER=^[A-Za-z0-9\\-/\\?&#*]+$
		 */
		Pattern patron10 = Pattern.compile("^[A-Za-z0-9\\-/\\?&#*]+$");
		String cadenas10 = "hola-123 ruta/img archivo? dato&valor clave#1 texto*";
		String[] palabras10 = cadenas10.split("\\s");
		for (String p : palabras10) {
			Matcher analisis = patron10.matcher(p);
			if (analisis.find()) {
				System.out.println(analisis.group());
			}
		}
	}
}
