package main;

import view.view_form;

public class main {
	public static void main(String[] args) {
		view_form vf=new view_form();
		vf.setVisible(true);
		
	}

}
