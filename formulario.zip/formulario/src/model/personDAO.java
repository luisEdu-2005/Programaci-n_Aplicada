package model;

import java.io.*;
import java.util.ArrayList;

public class personDAO {

    private person p;

    public personDAO() {
        p = new person();
    }

    public personDAO(person p_) {
        this.p = p_;
    }

    public boolean writePerson() throws IOException {

        FileWriter out = new FileWriter(
                "src/doc/person.txt",
                true
        );

        out.write(p.info() + "\n");

        out.close();

        return true;
    }

    public boolean deletePerson(String dni) throws IOException {

        File file = new File("src/doc/person.txt");

        BufferedReader br = new BufferedReader(
                new FileReader(file)
        );
        ArrayList<String> lines = new ArrayList<>();
        String line;
        boolean found = false;
        while((line = br.readLine()) != null) {
            String data[] = line.split(";");
            if(data.length >= 3) {
                if(!data[1].trim().equals(dni.trim())) {
                    lines.add(line);
                } else {
                    found = true;
                }
            }
        }

        br.close();

        FileWriter fw = new FileWriter(file,false);
        for(String l : lines) {
            fw.write(l + "\n");
        }
        fw.close();
        return found;
    }

    public boolean modifyPerson(
            String dni,
            String newName,
            String newEmail
    ) throws IOException {

        File file = new File("src/doc/person.txt");
        BufferedReader br = new BufferedReader(
                new FileReader(file)
        );
        ArrayList<String> lines = new ArrayList<>();
        String line;
        boolean found = false;
        while((line = br.readLine()) != null) {
            String data[] = line.split(";");
            if(data.length >= 3) {
                if(data[1].trim().equals(dni.trim())) {
                    lines.add(
                            newName + ";" +
                            dni + ";" +
                            newEmail
                    );
                    found = true;
                } else {
                    lines.add(line);
                }
            }
        }

        br.close();

        FileWriter fw = new FileWriter(file,false);
        for(String l : lines) {
            fw.write(l + "\n");
        }
        fw.close();
        return found;
    }
}