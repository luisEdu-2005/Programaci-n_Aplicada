package model;

import java.io.IOException;

public class testModel {
	
	public static void main(String[] args) {
		person p=new person("Alejandro Ruiz","175019152-8","aruizo@est.ups.edu.ec");
		personDAO pdao=new personDAO(p);
		try {
			pdao.writePerson();
			}catch(IOException e) {
				e.printStackTrace();
			}
	}
}
