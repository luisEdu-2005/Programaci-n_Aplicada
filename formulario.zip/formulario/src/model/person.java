package model;

import libreria_generica.generic;

public class person {
	private generic<String,String>dt_p;
	public person() {
		dt_p=new generic<>();
	}
	public person(String...data) {
		dt_p=new generic<>(data[0],data[1],data[2]);
	}
	public String getName() {
		return dt_p.getAttributeT1();
	}
	public String getDNI() {
		return dt_p.getAttributeT2();
	}
	public String getEmail() {
		return dt_p.getAttributeS3();
	}
	public void setNames(String n) {
		dt_p.setAttributeT1(n);
	}                                                                                                                          
	public void setDNI(String d) {
		dt_p.setAttributeT2(d);
	}
	public void setEmail(String e) {
		dt_p.setAttributeS3(e);
	}
	public String info() {
		return String.format("%s;%s;%s",getName(),getDNI(),getEmail());
	}

}
