package view;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controller.logic_view_form;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JButton;

public class view_form extends JFrame{

	public JTextField txt_names;
	public JTextField txt_cedula;
	public JTextField txt_email;

	public JButton btn_ok;
	public JButton btn_clear;
	public JButton btn_cancel;
	public JButton btn_modify;
	public JButton btn_delete;

	public view_form() {

		setTitle("REGISTRO");
		getContentPane().setLayout(null);
		setBounds(100,100,900,420);

		JPanel panel = new JPanel();
		panel.setBounds(10,10,860,360);
		getContentPane().add(panel);

		GridBagLayout gbl_panel = new GridBagLayout();

		gbl_panel.columnWidths = new int[]{120,600,0};

		gbl_panel.rowHeights = new int[]{40,40,40,20,50,50};

		gbl_panel.columnWeights = new double[]{0.0,1.0,Double.MIN_VALUE};

		gbl_panel.rowWeights = new double[]{0.0,0.0,0.0,0.0,0.0,0.0};

		panel.setLayout(gbl_panel);

		JLabel lblNewLabel_1 = new JLabel("Nombres:");
		lblNewLabel_1.setFont(new Font("Tahoma",Font.BOLD,18));

		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();

		gbc_lblNewLabel_1.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_1.insets = new Insets(0,0,15,10);
		gbc_lblNewLabel_1.gridx = 0;
		gbc_lblNewLabel_1.gridy = 0;

		panel.add(lblNewLabel_1,gbc_lblNewLabel_1);

		txt_names = new JTextField();

		txt_names.setFont(new Font("Tahoma",Font.PLAIN,18));

		GridBagConstraints gbc_txt_names = new GridBagConstraints();

		gbc_txt_names.insets = new Insets(0,0,15,0);
		gbc_txt_names.fill = GridBagConstraints.HORIZONTAL;
		gbc_txt_names.gridx = 1;
		gbc_txt_names.gridy = 0;

		panel.add(txt_names,gbc_txt_names);

		JLabel lblNewLabel = new JLabel("Cedula:");
		lblNewLabel.setFont(new Font("Tahoma",Font.BOLD,18));

		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();

		gbc_lblNewLabel.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel.insets = new Insets(0,0,15,10);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 1;

		panel.add(lblNewLabel,gbc_lblNewLabel);

		txt_cedula = new JTextField();

		txt_cedula.setFont(new Font("Tahoma",Font.PLAIN,18));

		GridBagConstraints gbc_txt_cedula = new GridBagConstraints();

		gbc_txt_cedula.insets = new Insets(0,0,15,0);
		gbc_txt_cedula.fill = GridBagConstraints.HORIZONTAL;
		gbc_txt_cedula.gridx = 1;
		gbc_txt_cedula.gridy = 1;

		panel.add(txt_cedula,gbc_txt_cedula);

		JLabel lblNewLabel_2 = new JLabel("Email:");
		lblNewLabel_2.setFont(new Font("Tahoma",Font.BOLD,18));

		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();

		gbc_lblNewLabel_2.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_2.insets = new Insets(0,0,15,10);
		gbc_lblNewLabel_2.gridx = 0;
		gbc_lblNewLabel_2.gridy = 2;

		panel.add(lblNewLabel_2,gbc_lblNewLabel_2);

		txt_email = new JTextField();

		txt_email.setFont(new Font("Tahoma",Font.PLAIN,18));

		GridBagConstraints gbc_txt_email = new GridBagConstraints();

		gbc_txt_email.insets = new Insets(0,0,15,0);
		gbc_txt_email.fill = GridBagConstraints.HORIZONTAL;
		gbc_txt_email.gridx = 1;
		gbc_txt_email.gridy = 2;

		panel.add(txt_email,gbc_txt_email);

		JPanel panel_1 = new JPanel();

		GridBagConstraints gbc_panel_1 = new GridBagConstraints();

		gbc_panel_1.gridx = 1;
		gbc_panel_1.gridy = 4;

		panel.add(panel_1,gbc_panel_1);

		btn_ok = new JButton("GUARDAR");
		btn_ok.setEnabled(false);
		btn_ok.setFont(new Font("Tahoma",Font.BOLD,18));
		panel_1.add(btn_ok);

		btn_clear = new JButton("LIMPIAR");
		btn_clear.setFont(new Font("Tahoma",Font.BOLD,18));
		panel_1.add(btn_clear);

		btn_cancel = new JButton("CANCELAR");
		btn_cancel.setFont(new Font("Tahoma",Font.BOLD,18));
		panel_1.add(btn_cancel);

		JPanel panel_2 = new JPanel();

		GridBagConstraints gbc_panel_2 = new GridBagConstraints();

		gbc_panel_2.gridx = 1;
		gbc_panel_2.gridy = 5;

		panel.add(panel_2,gbc_panel_2);

		btn_modify = new JButton("MODIFICAR");
		btn_modify.setFont(new Font("Tahoma",Font.BOLD,18));
		panel_2.add(btn_modify);

		btn_delete = new JButton("ELIMINAR");
		btn_delete.setFont(new Font("Tahoma",Font.BOLD,18));
		panel_2.add(btn_delete);

		new logic_view_form(this);
	}
}