package controller;

public interface validable {

	public static boolean valNames(String name) {

		return !name.isBlank() &&
			   name.matches("^([A-ZÁÉÍÓÚ][a-záéíóú]+\\s?){2,4}$");
	}

	public static boolean valDNI(String dni) {

		return !dni.isBlank() &&
			   dni.matches("^[0-9]{10}$");
	}

	public static boolean valEmail(String email) {

		return !email.isBlank() &&
			   email.matches("^[\\w.-]+@([\\w-]+\\.)+[a-zA-Z]{2,}$");
	}
}