package controller;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import javax.swing.JOptionPane;
import model.person;
import model.personDAO;
import view.view_form;

public class logic_view_form implements KeyListener,ActionListener{

    private view_form vf;
    private personDAO pdao;

    public logic_view_form(view_form vf){

        this.vf=vf;

        this.vf.txt_names.addKeyListener(this);
        this.vf.txt_cedula.addKeyListener(this);
        this.vf.txt_email.addKeyListener(this);

        this.vf.btn_ok.addActionListener(this);
        this.vf.btn_modify.addActionListener(this);
        this.vf.btn_delete.addActionListener(this);
        this.vf.btn_clear.addActionListener(this);
        this.vf.btn_cancel.addActionListener(this);
    }

    @Override
    public void keyTyped(KeyEvent e){}

    @Override
    public void keyPressed(KeyEvent e){

        if(e.getSource()==vf.txt_names){

            if(e.getKeyCode()==e.VK_ENTER){

                if(!validable.valNames(vf.txt_names.getText())){

                    vf.txt_names.setBackground(Color.red);

                    JOptionPane.showMessageDialog(vf,"Nombre inválido");

                }else{

                    vf.txt_names.setBackground(Color.green);
                    vf.txt_cedula.requestFocusInWindow();
                }
            }

        }else if(e.getSource()==vf.txt_cedula){

            if(e.getKeyCode()==e.VK_ENTER){

                if(!validable.valDNI(vf.txt_cedula.getText())){

                    vf.txt_cedula.setBackground(Color.red);

                    JOptionPane.showMessageDialog(vf,"Cédula inválida");

                }else{

                    vf.txt_cedula.setBackground(Color.green);
                    vf.txt_email.requestFocusInWindow();
                }
            }

        }else if(e.getSource()==vf.txt_email){

            if(e.getKeyCode()==e.VK_ENTER){

                if(!validable.valEmail(vf.txt_email.getText())){

                    vf.txt_email.setBackground(Color.red);

                    JOptionPane.showMessageDialog(vf,"Email inválido");

                }else{

                    vf.txt_email.setBackground(Color.green);
                    vf.btn_ok.setEnabled(true);
                    vf.btn_ok.requestFocusInWindow();
                }
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e){}

    @Override
    public void actionPerformed(ActionEvent e){

        if(e.getSource()==vf.btn_ok){

            savePerson(
                    vf.txt_names.getText(),
                    vf.txt_cedula.getText(),
                    vf.txt_email.getText()
            );

        }else if(e.getSource()==vf.btn_modify){

            modifyPerson();

        }else if(e.getSource()==vf.btn_delete){

            deletePerson();

        }else if(e.getSource()==vf.btn_clear){

            clearFields();

        }else if(e.getSource()==vf.btn_cancel){

            System.exit(0);
        }
    }

    private void savePerson(String...data){

        if(data[0].isBlank()||data[1].isBlank()||data[2].isBlank()){

            JOptionPane.showMessageDialog(vf,"No deje campos vacíos");
            return;
        }

        if(!validable.valNames(data[0])){

            JOptionPane.showMessageDialog(vf,"Nombre inválido");
            return;
        }

        if(!validable.valDNI(data[1])){

            JOptionPane.showMessageDialog(vf,"Cédula inválida");
            return;
        }

        if(!validable.valEmail(data[2])){

            JOptionPane.showMessageDialog(vf,"Email inválido");
            return;
        }

        pdao=new personDAO(new person(data[0],data[1],data[2]));

        try{

            if(pdao.writePerson()){

                JOptionPane.showMessageDialog(vf,"Registro exitoso");

                clearFields();
            }

        }catch(IOException e){

            JOptionPane.showMessageDialog(vf,"Error al guardar");
        }
    }

    private void deletePerson(){

        String cedula=JOptionPane.showInputDialog(vf,"Ingrese la cédula a eliminar:");

        if(cedula==null||cedula.isBlank()){

            JOptionPane.showMessageDialog(vf,"Ingrese una cédula");
            return;
        }

        if(!validable.valDNI(cedula)){

            JOptionPane.showMessageDialog(vf,"Cédula inválida");
            return;
        }

        pdao=new personDAO();

        try{

            if(pdao.deletePerson(cedula)){

                JOptionPane.showMessageDialog(vf,"Registro eliminado");

            }else{

                JOptionPane.showMessageDialog(vf,"Cédula no encontrada");
            }

        }catch(IOException e){

            JOptionPane.showMessageDialog(vf,"Error al eliminar");
        }
    }

    private void modifyPerson(){

        String cedula=JOptionPane.showInputDialog(vf,"Ingrese la cédula a modificar:");

        if(cedula==null||cedula.isBlank()){

            JOptionPane.showMessageDialog(vf,"Debe ingresar una cédula");
            return;
        }

        if(!validable.valDNI(cedula)){

            JOptionPane.showMessageDialog(vf,"Cédula inválida");
            return;
        }

        String nuevoNombre=JOptionPane.showInputDialog(vf,"Nuevo nombre:");

        if(nuevoNombre==null||nuevoNombre.isBlank()){

            JOptionPane.showMessageDialog(vf,"Debe ingresar un nombre");
            return;
        }

        if(!validable.valNames(nuevoNombre)){

            JOptionPane.showMessageDialog(vf,"Nombre inválido");
            return;
        }

        String nuevoEmail=JOptionPane.showInputDialog(vf,"Nuevo email:");

        if(nuevoEmail==null||nuevoEmail.isBlank()){

            JOptionPane.showMessageDialog(vf,"Debe ingresar un email");
            return;
        }

        if(!validable.valEmail(nuevoEmail)){

            JOptionPane.showMessageDialog(vf,"Email inválido");
            return;
        }

        pdao=new personDAO();

        try{

            if(pdao.modifyPerson(cedula,nuevoNombre,nuevoEmail)){

                JOptionPane.showMessageDialog(vf,"Registro modificado");

            }else{

                JOptionPane.showMessageDialog(vf,"Cédula no encontrada");
            }

        }catch(IOException e){

            JOptionPane.showMessageDialog(vf,"Error al modificar");
        }
    }

    private void clearFields(){

        vf.txt_names.setText("");
        vf.txt_cedula.setText("");
        vf.txt_email.setText("");

        vf.txt_names.setBackground(Color.white);
        vf.txt_cedula.setBackground(Color.white);
        vf.txt_email.setBackground(Color.white);

        vf.btn_ok.setEnabled(false);
    }
}